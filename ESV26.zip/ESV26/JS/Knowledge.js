﻿


////Opon Modal Test
$('document').ready(function(){
        /// Apply Page theme
           setPageTheme('knowledge');
                                                                          
           /////get Sauce Topics
            getSAUCETopics();
          getSAUCE_SubTopics();
            /////////////////////////////////
            ///Load left nav
            leftScrollSpy();
            
            /////apply page styling 
        
 
         
})



/////////get knowledge attachments
function getknowledgeAttachments(knowledgeID){
  var figcount=0;
  DocumentQuery = '<Query><Where><Contains><FieldRef Name="FileDirRef"/><Value Type="Text">Attachment_'+knowledgeID+'_Files</Value></Contains></Where><OrderBy><FieldRef Name="Created" Ascending="False" /></OrderBy></Query>'

    ////////////////SPServices Get List Items
                               $().SPServices({
                                        operation: "GetListItems",
                                        async: false,
                                        listName: 'SAUCE Attachments',
                                        CAMLViewFields: "<ViewFields><FieldRef Name='Description' /><FieldRef Name='Alt' /><FieldRef Name='ID' /><FieldRef Name='FileDirRef' /><FieldRef Name='Created' /><FieldRef Name='_SourceUrl' /><FieldRef Name='_SourceUrl' /><FieldRef Name='FileLeafRef' /><FieldRef Name='ID' /><FieldRef Name='Author' /><FieldRef Name='FileDirRef' /><FieldRef Name='DocIcon' /><FieldRef Name='FileRef' /></ViewFields>",
                                        CAMLQuery:DocumentQuery ,
                                        CAMLQueryOptions: '<QueryOptions><ViewAttributes Scope="Recursive"/></QueryOptions>',
                                        completefunc: function (xData, Status) {
                                          $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                          var Document_ID = $(this).attr("ows_ID")
                                          var Document_Name =$(this).attr("ows_FileLeafRef").substring( $(this).attr("ows_FileLeafRef").indexOf('#')+1);
                                          var Document_URL = window.location.protocol + "//" + window.location.host + "/" + $(this).attr("ows_FileDirRef").substring($(this).attr("ows_FileDirRef").indexOf('#')+1)+"/"+Document_Name;
                                          var DocumentLink = $(this).attr("ows_FileRef").substring( $(this).attr("ows_FileRef").indexOf('#')+1);
                                          var fileType="document" ;
                                          var AltTxt =  $(this).attr("ows_Alt");
                                          var imgtxt =  $(this).attr("ows_Description");
                                          var currentsiteSting = window.location.protocol + "//" + window.location.host + "/" + $(this).attr("ows_FileDirRef").substring($(this).attr("ows_FileDirRef").indexOf('#')+1,$(this).attr("ows_FileDirRef").indexOf('SAUCE')+5)
                                        
 
                                          
                                        ///set document icon
                                        var docicon = $(this).attr("ows_DocIcon");  
                                          if(docicon.indexOf('do') > -1){//Word Document
                                               docicon='fa-file-word-o'    
                                               Document_URL =currentsiteSting +'/_layouts/15/WopiFrame.aspx?sourcedoc='+Document_URL+'&action=default'                                                                                                                          
                                         }else if(docicon.indexOf('pdf') > -1){
                                                docicon='fa-file-pdf-o'                                                                                                                            
                                         }else if(docicon.indexOf('xl') > -1){
                                                  docicon='fa-file-excel-o'                 
                                         }else if(docicon.indexOf('ppt') > -1){
                                                  docicon='fa-file-powerpoint-o' ;
                                                   Document_URL =currentsiteSting +'/_layouts/15/WopiFrame.aspx?sourcedoc='+Document_URL+'&action=default'                    
                                         }else if(docicon.indexOf('jpg') > -1 || docicon.indexOf('bmp') > -1 || docicon.indexOf('png') > -1 || docicon.indexOf('gif') > -1 ){
                                                  docicon='fa-file-image-o';  
                                                  fileType = 'Image';                                                   
                                         }else if(docicon.indexOf('msg') > -1 ){
                                                  docicon='fa-envelope-o'                             
                                         }else if(docicon.indexOf('zip') > -1 ){
                                                  docicon='fa-file-archive-o'                             
                                         }else{
                                              docicon = 'fa-file-o'
                                           }
                                    /////////////////////////////////////
                                      if(fileType == 'Image' ){
                                       ///append image to page
                                   

                                        figcount +=1
 

                                       
                                           ///append image to page
                                            $('#knowledgeImages'+knowledgeID).append('<figure class="col-md-4">'+                                           
								              '<div class="view overlay z-depth-2">'+
								                   '<img src="'+Document_URL+'" class="img-fluid " style="width:100%;height:200px" alt="'+AltTxt+'">'+
								                   '<a  href="'+Document_URL+'" class="temp-attachment"  target="_blank">'+
								                        '<div class="mask rgba-white-slight"></div>'+
								                 ' </a>'+
								               '</div>'+
								               '<br>'+	
								               '<span class="fig-name"><b style="color:'+primecolorCode +'" >Figure '+figcount+'.</b>'+AltTxt+imgtxt+'<span>'+														
								            '</figure>'
								             )

															

                                      }else{
                                     
                                       
                                         $('#knowledgeFiles'+knowledgeID).append( 
                                           
									           '<li class="list-group-item"><a style="color:'+primecolorCode +'"  target="_blank" href="'+Document_URL+'"><b><i class="fa '+docicon+'" ></i> '+Document_Name+'</b></a></li>'
									        )
																                                      
                                      
                                      }
                                                                                                                         
                                      //////////////////////////////////////////     
                                     })
                                     
                                    }
                                   });
                                   ///////////////////////////////////////////End SP services  



 


}

////////////////////////////////////////////
