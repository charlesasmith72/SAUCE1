﻿

$('document').ready(function(){
        /// Apply Page theme
           setPageTheme('Posts');
                                                                          
           /////get Sauce Topics
          //  getSAUCETopics();
         // getSAUCE_SubTopics();
            /////////////////////////////////
            ///Load left nav
            leftScrollSpy();
            
            /////apply page styling 
            ///set Primary Color
                    $('.primeColor').css('color','#0072bc');
                    $('.primeColor2').css('color','black')     
 
         ////get and set Selectable options
          setSelections('#TopicSelect','SAUCE Topics' )
})

/////////////////////////////////// set New Posts left naviugation PageHeader-LI
function setNewPostNav(){

   



} 
//////////
function showPostForm(PostView){

//// post View Radios
$('#postview-div').hide();  

 ////set new Topic View
    if(PostView == "Topic"){
    
       ////show main form
       $('#MainForm').show();
       ////show topic Title
       $('.topic-field').show();
    }else if(PostView == "Post"){
////set new Topic View
    
    
       ////show main form
       $('#MainForm').show();
       ////show topic Title
       $('.post-field').show();
    }


}

////////////////////////////////////
/////preview source code
   function previewSourceCode(){
        var SourceCode =$('#SourceInput').val();
          ///set preview
            $('#SourceInput-Well').empty().append(SourceCode).show();
   
   }

//////////////////////////////////////
