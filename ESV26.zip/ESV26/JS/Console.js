﻿///////get sharepoint data
function getSPdata(){ 
var queryStringVals = $().SPServices.SPGetQueryString();
var postIDparam = queryStringVals["tryid"];

   var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+ 
                             "<FieldRef Name='ID' />"+ 
                             "<FieldRef Name='Description' />"+ 
                             "<FieldRef Name='Topic' />"+
                             "<FieldRef Name='HTML' />"+  
                             "<FieldRef Name='Source_x0020_Code' />"+
                             "<FieldRef Name='Note' />"+                                                            
                              "</ViewFields>"
 
         
                  ////////////////SPServices Get List Items Office Directory
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: "SAUCE Posts",
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query><Where><Eq><FieldRef Name="ID"/><Value Type="Text">'+postIDparam +'</Value></Eq></Where><OrderBy><FieldRef Name="Title" Ascending="False" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                                                                                                                                                                                                                                                                                                                                                     
                                                       var postTitle = $(this).attr("ows_Title");
                                                       var postID = $(this).attr("ows_ID");
                                                       var postSourceCode = $(this).attr("ows_Source_x0020_Code");
                                                       
                                                     
                                                 ///set console title
                                                 $('#result-title').html('Code Example: '+postTitle );
                                                 ///set source code
                                                 $('#code-wrap > pre.code').html(postSourceCode );
  
                                                       
                                    })
                                      }
                                   })  
                    //////////End SpServcies


}

/////////////////
function runCode(){
	///save code edits
      updateCode()
   ///empty iframe wrap
   $('#iframe-wrap').empty()
   
   ////add a blank iframe
   $('#iframe-wrap').append('<iframe id="SAUCEIframe" src="Console-Html.aspx" style="min-height:500px;overflow:scroll"  frameborder="0"  width="100%" title="SAUCE Code Results"> ')
    var JqueryLink= '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>'
    var iframeHtml =$('#code-wrap > div > pre.source').text();
   //add html
   document.getElementById('SAUCEIframe').contentWindow.document.write(iframeHtml);

}
////////////edit code modal
function editCode(){
/////update edit button
   $('#editCodeBtn').html('Done Editing <i aria-hidden="true" class="glyphicon glyphicon-check"></i>').attr('onclick','updateCode()')
//make editable
$('#code-wrap > div > pre.code').attr('contenteditable','true');
$('#code-wrap > div > pre.source').attr('contenteditable','true');


///

};
//////////////
///save code edits
function updateCode(){
var currentCodeView = "code" 
   if($( "#code-wrap > div > .tabs > li.code" ).hasClass( "active" )){
     currentCodeView = "code"
   }else if($( "#code-wrap > div > .tabs > li.source" ).hasClass( "active" )){
     currentCodeView = "source"
   }
/////update edit button
   $('#editCodeBtn').html('Edit Code <i aria-hidden="true" class="glyphicon glyphicon-pencil"></i>').attr('onclick','editCode()')
//disable editable
		$('#code-wrap > div > pre.code').removeAttr('contenteditable','true');
		$('#code-wrap > div > pre.source').removeAttr('contenteditable','true');

//reset code editor
var newSourceCode ="";
if(currentCodeView == "code"){
     newSourceCode =  $('#code-wrap > div > pre.code').text().replace(/</g,"&#60;").replace(/>/g,"&#62;");
    }else if(currentCodeView == "source"){
     newSourceCode =  $('#code-wrap > div > pre.source').text().replace(/</g,"&#60;").replace(/>/g,"&#62;");
    }
    
  $('#code-wrap').empty()//
  $('#code-wrap').append('<pre class="code"  data-language="html">'+newSourceCode+'</pre>')

//reset code highlight js
$('#code-wrap > pre.code').highlight({source:1, zebra:1, indent:'space', list:'ol',attribute: 'data-language'});


}
////////////////////////////

