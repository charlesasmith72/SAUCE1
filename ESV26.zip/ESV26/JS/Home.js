﻿////Opon Modal Test
$('document').ready(function(){

   /// Apply Page theme
          //  setPageTheme('Home');

   $('.cover-text').addClass('animated fadeInDown')


         
})
