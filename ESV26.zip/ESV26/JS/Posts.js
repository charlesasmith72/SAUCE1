﻿$('document').ready(function(){
        /// Apply Page theme
           setPageTheme('Posts');
                                                                          
  
            
            /////apply page styling 
            ///set Primary Color
                    $('.primeColor').css('color','#0072bc');
                    $('.primeColor2').css('color','black')     
 
         
})



////////////edit code modal
function editCode(){
/////update edit button
   $('#editCodeBtn').html('Done Editing <i aria-hidden="true" class="glyphicon glyphicon-check"></i>').attr('onclick','updateCode()')
//make editable
$('pre.code').attr('contenteditable','true');
$('pre.source').attr('contenteditable','true');

}
///
///save code edits
function updateCode(){
var currentCodeView = "code" 
   if($( "li.code" ).hasClass( "active" )){
     currentCodeView = "code"
   }else if($( "li.source" ).hasClass( "active" )){
     currentCodeView = "source"
   }
/////update edit button
   $('#editCodeBtn').html('Edit Code <i aria-hidden="true" class="glyphicon glyphicon-pencil"></i>').attr('onclick','editCode()')
//disable editable
$('pre.code').removeAttr('contenteditable','true');
$('pre.source').removeAttr('contenteditable','true');

//reset code editor
var newSourceCode ="";
if(currentCodeView == "code"){
    newSourceCode =  $('pre.code').text().replace(/</g,"&#60;").replace(/>/g,"&#62;");
    }else if(currentCodeView == "source"){
    newSourceCode =  $('pre.source').text().replace(/</g,"&#60;").replace(/>/g,"&#62;");
    }
    
    $('#code-wrap').empty().append('<pre class="code"  data-language="html">'+newSourceCode+'</pre>')

//reset code highlight js
$('pre.code').highlight({source:1, zebra:1, indent:'space', list:'ol',attribute: 'data-language'});


}
////////////////////////////
/////////////Save and Upade Post

function postSAUCE(saveMode){
  /////save variables
      ////Details and Description 
          var postTitle = $('#TitleInput').val();
          var postDesc =  $('#DescribeInput').val();
          var postSubmissionType =  $("input[name='SubmissionOptions']:checked").val();
          var postCategory  =  $('#CategoryInput').val();
          var postTopic  =  $('#TopicInput').val();


        ////Source Code 
        
        
        
        ///Plugins and Templates 
         var pluginInstructions =  $('#InstructionInput').val();alert(pluginInstructions )
        
        
        
        ////Tags and Notes 
          var tagsandNotes =  $('#NotesInput').val();alert(tagsandNotes )
 
          
          
          ///save
          
         

};
/////////////////////////////////////////////
