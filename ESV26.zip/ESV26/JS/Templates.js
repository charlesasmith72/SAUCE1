﻿


////Opon Modal Test
$('document').ready(function(){
        /// Apply Page theme
           setPageTheme('Templates');
                                                                          
           /////get Sauce Topics
            getSAUCETopics();
        //  getSAUCE_SubTopics();
            /////////////////////////////////
            ///Load left nav
            leftScrollSpy();
            
       
 
         
})


/////////get Template attachments
function getTemplateAttachments(templateID){
   ///add table
    $('#fileWrap'+templateID).append(
						'<table id="templatetable'+templateID+'" class="table table-striped table-responsive-md btn-table">'+
						    '<thead>'+
						        '<tr>'+
						            '<th><span class="sr-only">File Name</span></th>'+
						            '<th><span class="sr-only">Download Buttons</span></th>'+
						        '</tr>'+
						    '</thead>'+
						    '<tbody>'+
						    '</tbody>'+
						'</table>' );

  DocumentQuery = '<Query><Where><Contains><FieldRef Name="FileDirRef"/><Value Type="Text">Template_'+templateID+'Attachment</Value></Contains></Where><OrderBy><FieldRef Name="Created" Ascending="False" /></OrderBy></Query>'

    ////////////////SPServices Get List Items
                               $().SPServices({
                                        operation: "GetListItems",
                                        async: false,
                                        listName: 'SAUCE Attachments',
                                        CAMLViewFields: "<ViewFields><FieldRef Name='ID' /><FieldRef Name='FileDirRef' /><FieldRef Name='Created' /><FieldRef Name='_SourceUrl' /><FieldRef Name='_SourceUrl' /><FieldRef Name='FileLeafRef' /><FieldRef Name='ID' /><FieldRef Name='Author' /><FieldRef Name='FileDirRef' /><FieldRef Name='DocIcon' /><FieldRef Name='FileRef' /></ViewFields>",
                                        CAMLQuery:DocumentQuery ,
                                        CAMLQueryOptions: '<QueryOptions><ViewAttributes Scope="Recursive"/></QueryOptions>',
                                        completefunc: function (xData, Status) {
                                          $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                          var Document_ID = $(this).attr("ows_ID")
                                          var Document_Name =$(this).attr("ows_FileLeafRef").substring( $(this).attr("ows_FileLeafRef").indexOf('#')+1);
                                          var Document_URL = window.location.protocol + "//" + window.location.host + "/" + $(this).attr("ows_FileDirRef").substring($(this).attr("ows_FileDirRef").indexOf('#')+1)+"/"+Document_Name;
                                          var DocumentLink = $(this).attr("ows_FileRef").substring( $(this).attr("ows_FileRef").indexOf('#')+1);
                                          var fileType="document"  
                                        ///set document icon
                                        var docicon = $(this).attr("ows_DocIcon");  
                                          if(docicon.indexOf('do') > -1){//Word Document
                                               docicon='fa-file-word-o'                                                                                                                              
                                         }else if(docicon.indexOf('pdf') > -1){
                                                docicon='fa-file-pdf-o'                                                                                                                            
                                         }else if(docicon.indexOf('xl') > -1){
                                                  docicon='fa-file-excel-o'                 
                                         }else if(docicon.indexOf('ppt') > -1){
                                                  docicon='fa-file-powerpoint-o'                    
                                         }else if(docicon.indexOf('jpg') > -1 || docicon.indexOf('bmp') > -1 || docicon.indexOf('png') > -1 || docicon.indexOf('gif') > -1 ){
                                                  docicon='fa-file-image-o';  
                                                  fileType = 'Image';                                                   
                                         }else if(docicon.indexOf('msg') > -1 ){
                                                  docicon='fa-envelope-o'                             
                                         }else if(docicon.indexOf('zip') > -1 ){
                                                  docicon='fa-file-archive-o'                             
                                         }else{
                                              docicon = 'fa-file-o'
                                           }
                                    /////////////////////////////////////
                                      if(fileType == 'Image' ){
                                           ///append image to page
                                             $('#imageWrap'+templateID).append('<figure class="col-md-4">'+
								                '<div class="view overlay">'+
								                    '<img src="'+Document_URL+'" class="img-fluid" style="width:100%;height:200px" alt="First sample image">'+
								                    '<a  href="'+Document_URL+'" class="temp-attachment"  target="_blank">'+
								                        '<div class="mask rgba-white-slight"></div>'+
								                   ' </a>'+
								                '</div>'+															
								            '</figure>')

															

                                      }else{
                                         $('#templatetable'+templateID+' > tbody').append('<tr>'+
									            '<th style="font-size:18px" scope="row"><i class="fa '+docicon+'" ></i> '+Document_Name+'</th>'+
									            '<td><a type="button"    download="'+Document_Name+'"  href="'+Document_URL+'"  class="btn btn-primary btn-sm waves-effect temp-attachment"><i class="fa fa-arrow-down" aria-hidden="true"></i> Download <span class="sr-only">'+Document_Name+'</span></a></td>'+
									        '</tr>')
																                                      
                                      
                                      }
                                                                                                                         
                                      //////////////////////////////////////////     
                                     })
                                     
                                    }
                                   });
                                   ///////////////////////////////////////////End SP services  



 


}

////////////////////////////////////////////
/////////get Template attachments
function getTemplate(templateID){

  DocumentQuery = '<Query><Where><Contains><FieldRef Name="FileDirRef"/><Value Type="Text">Template_'+templateID+'_Files</Value></Contains></Where><OrderBy><FieldRef Name="Created" Ascending="False" /></OrderBy></Query>'

    ////////////////SPServices Get List Items
                               $().SPServices({
                                        operation: "GetListItems",
                                        async: false,
                                        listName: 'SAUCE Templates',
                                        CAMLViewFields: "<ViewFields><FieldRef Name='ID' /><FieldRef Name='FileDirRef' /><FieldRef Name='Created' /><FieldRef Name='_SourceUrl' /><FieldRef Name='_SourceUrl' /><FieldRef Name='FileLeafRef' /><FieldRef Name='ID' /><FieldRef Name='Author' /><FieldRef Name='FileDirRef' /><FieldRef Name='DocIcon' /><FieldRef Name='FileRef' /></ViewFields>",
                                        CAMLQuery:DocumentQuery ,
                                        CAMLQueryOptions: '<QueryOptions><ViewAttributes Scope="Recursive"/></QueryOptions>',
                                        completefunc: function (xData, Status) {
                                          $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                          var Document_ID = $(this).attr("ows_ID")
                                          var Document_Name =$(this).attr("ows_FileLeafRef").substring( $(this).attr("ows_FileLeafRef").indexOf('#')+1);
                                          var Document_URL = window.location.protocol + "//" + window.location.host + "/" + $(this).attr("ows_FileDirRef").substring($(this).attr("ows_FileDirRef").indexOf('#')+1)+"/"+Document_Name;
                                          var DocumentLink = $(this).attr("ows_FileRef").substring( $(this).attr("ows_FileRef").indexOf('#')+1);
                                          var fileType="document"  ;
                                          
                                        ///set document icon
                                        var docicon = $(this).attr("ows_DocIcon");  
                                          if(docicon.indexOf('do') > -1){//Word Document
                                               docicon='fa-file-word-o'                                                                                                                              
                                         }else if(docicon.indexOf('pdf') > -1){
                                                docicon='fa-file-pdf-o'                                                                                                                            
                                         }else if(docicon.indexOf('xl') > -1){
                                                  docicon='fa-file-excel-o'                 
                                         }else if(docicon.indexOf('ppt') > -1){
                                                  docicon='fa-file-powerpoint-o'                    
                                         }else if(docicon.indexOf('jpg') > -1 || docicon.indexOf('bmp') > -1 || docicon.indexOf('png') > -1 || docicon.indexOf('gif') > -1 ){
                                                  docicon='fa-file-image-o';  
                                                  fileType = 'Image';                                                   
                                         }else if(docicon.indexOf('msg') > -1 ){
                                                  docicon='fa-envelope-o'                             
                                         }else if(docicon.indexOf('zip') > -1 ){
                                                  docicon='fa-file-archive-o'                             
                                         }else{
                                              docicon = 'fa-file-o'
                                           }
                                    /////////////////////////////////////
                                       
                                         $('#templatetable'+templateID+' > tbody').append('<tr>'+
									            '<th  style="font-size:18px" scope="row"><i class="fa '+docicon+'" ></i> '+Document_Name+'</th>'+
									            '<td><a type="button"    download="'+Document_Name+'"  href="'+Document_URL+'"  class="btn btn-primary btn-sm waves-effect temp-attachment"><i class="fa fa-arrow-down" aria-hidden="true"></i> Download <span class="sr-only">'+Document_Name+'</span></a></td>'+
									        '</tr>')
																                                      
                                  
                                                                                                                         
                                      //////////////////////////////////////////     
                                     })
                                     
                                    }
                                   });
                                   ///////////////////////////////////////////End SP services  



 


}

////////////////////////////////////////////