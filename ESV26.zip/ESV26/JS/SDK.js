﻿


////Opon Modal Test
$('document').ready(function(){
        /// Apply Page theme
            setPageTheme('SDK');
                                                                          
           /////get Sauce Topics
         getSAUCETopics();
         getSAUCE_SubTopics();
            /////////////////////////////////
            ///Load left nav
         leftScrollSpy();
            /////apply page styling 
           
         ///set Iframe
        // setSDKIframe()

})


///////example modal
function setSDKIframe(iframeID,postSourceCode){
  

 ////add a blank iframe
 // $('#'+iframeID).append('<iframe id="SDK'+iframeID+'-Iframe" src="Console-Html.aspx" style="height:500px;overflow:auto"  frameborder="0"  width="100%" title="SAUCE Code Results"/> ')
    var iframeHtml = postSourceCode;

     var styleSheet = '<style type="text/css">'+ 
							'body{'+
								'margin:10px!important'+
							'}'+
							'</style>'
      var convertediframeHtml = styleSheet+postSourceCode
      
   //add html
  document.getElementById('SDK'+iframeID+'-Iframe').contentWindow.document.write(convertediframeHtml);



}