﻿
var PageLocationPath =  window.location.href;
var PageQueryString = $().SPServices.SPGetQueryString();
var attachmentType_Param = PageQueryString["doclib"];
   
 
 _spBodyOnLoadFunctionNames.push("SpdocReady");
///sharepoint document ready
function SpdocReady() {

      ////check page location
   if(PageLocationPath.indexOf('Forms/CustomEdit.aspx') >= 0 ){////If edit form
    ///hide form
 // $('form[action*="CustomEdit.aspx"]').show();
        ////Set upload form 
       
        if(attachmentType_Param == 'SAUCE Templates' ){ 
               saveTemp();
          }else if(attachmentType_Param == 'SAUCE Attachments' ){
              
             saveAttachment()
          }
       //////////////////////////////
     }
 } 
//////end sp body load
 


/////////Save functions
function saveTemp(){
        //Dev Save function       
          if (!PreSaveItem()) return false;WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions("ctl00$ctl40$g_f5033ca5_8c17_404f_8dcb_33be24e8e232$savebutton2$ctl00$diidIOSaveItem", "", true, "", "", false, true))  
          
    
       }
/////////////////////
function saveAttachment(){
        //Dev Save function 
       if (!PreSaveItem()) return false;WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions("ctl00$ctl40$g_df73c559_a3c4_45a8_bc4f_7026bc55d29a$savebutton2$ctl00$diidIOSaveItem", "", true, "", "", false, true)); 
        
}
/////////////////////
