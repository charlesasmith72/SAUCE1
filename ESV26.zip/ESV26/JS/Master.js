﻿
var scrolled=0;

///Global Variables
var PageTitle;
var primecolorCode;
var PageDesc;
var PageSearch ;
var curUserName;
var curFullUserName;                       
var curUserEmail;
var hasLeftNav = "Yes";
var pagefilter ="";
var sauceTopicID = '';
var saucePostID = '31';

var currnentAspx = function(){
                        ///remove extra parameters
                        var link=""
					      if(window.location.href.indexOf('#') >= 0){
					       ///Redirect Page
					       var redirectLink = window.location.href.substring(0,window.location.href.indexOf('#'))      
					         link  = redirectLink 
					         
					      }else{
					       ///Redirect Page      
					       link  = window.location.href
					      }
					  // 
                       //var link = window.location.href.substring(0,window.location.href.indexOf('#'));
                           return link;
                          };
$('document').ready(function(){
            /////////////////get user information   
             $().SPServices({
                    operation: "GetUserInfo",
                        async: false,
                         userLoginName: $().SPServices.SPGetCurrentUser(),
                       completefunc: function (xData, Status) {
                        
                      $(xData.responseXML).find("User").each(function() {
                       
                         //curUserId = $(this).attr("ID");
                          curUserName = $(this).attr("Name");
                          curFullUserName = $(this).attr("ID")+";#"+$(this).attr("Name");
                          curUserEmail = $(this).attr("Email");
                          
                              });
                            }
                         });
 /////////////////////////////////
            ////////Set user profile
             $('.SPName').html( curUserName);
    ///////////////////////////////////
/* smooth scrolling for boottsrap link buttons */
$('.scroll-btn[href*="#"]').not('.scroll-btn[href="#"]').click(function() {
 

    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
      if (target.length) {
        $('html,body').animate({
          scrollTop: target.offset().top - 80
        }, 1500);
        return false;
      }
    }
});

  $('body').on('click','.testbtn',function(){
  
  
    
    var p = $('#scrollEnd');

var position = p.position();
      alert(position.top )
      $('body').animate({
          scrollTop: position.top 
        }, 1500);


  })
 

})/////////////////////////////////
//////////////
////Set left nav scroll spy
function leftScrollSpy(){

 
               /* activate sidebar */
//$('#sidebar').affix({
 // offset: {
 //   top: 235
//  }
//});
  $("#sidebar").sticky({topSpacing:45 });
//$('body').scrollspy({ target: '#myScrollspy' })


/* activate scrollspy menu */
var $body   = $(document.body);
var navHeight = $('.navbar').outerHeight(true) + 10;

$body.scrollspy({
	target: '#sidebar',
	offset: navHeight
});


 


/* smooth scrolling sections */
$('a[href*="#"]').not('a[href="#"],.not-smooth').click(function() {
    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
      if (target.length) {
        $('html,body').animate({
          scrollTop: target.offset().top - 9000
        }, 1000);
        return false;
      }
    }
});

////Force Zoom Test
//set styling
 $('.primeColor').css('color',primecolorCode );
 //$('.leftnav-topic.active').css('border','0 '+primecolorCode +' solid !important')
 $('.leftnav-topic, .bs-callout').css('border-color',primecolorCode)

};
/////////////////////

/////////////////////
////////get SAUCE Topics
   function  getSAUCETopics(){
     
 
           var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+ 
                             "<FieldRef Name='ID' />"+ 
                             "<FieldRef Name='Description' />"+ 
                             "<FieldRef Name='Page' />"+ 
                             "<FieldRef Name='HTML' />"+
                             "<FieldRef Name='Tags' />"+ 
                             "<FieldRef Name='Instructions' />"+                                                          
                              "</ViewFields>"
 
         
                  ////////////////SPServices Get List Items Office Directory
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: "SAUCE Topics",
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query>'+
                                          '<Where>'+
											'<Contains>'+
												'<FieldRef Name="Page"/>'+
												'<Value Type="Text">'+pagefilter+'</Value>'+
											'</Contains>'+
										'</Where>'+
                                          '<OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                                                                                                                                                                                                                                                                                                                                                     
                                                       var TopicTitle = $(this).attr("ows_Title");
                                                       var TopicID = $(this).attr("ows_ID");
                                                       var TopicDescription = $(this).attr("ows_Description");
                                                       if(TopicDescription === undefined){TopicDescription =''
                                                       }else{                                                      
                                                          TopicDescription  = ckVal_ConvertedBack($(this).attr("ows_Description"));
 
                                                       }
                                                       var TopicHTML = $(this).attr("ows_HTML");
                                                       if(TopicHTML === undefined){TopicHTML=''
                                                       }else{                                                      
                                                          TopicHTML = ckVal_ConvertedBack($(this).attr("ows_HTML"));
 
                                                       }

                                                       var TopicTags ="";if( $(this).attr("ows_Tags") != undefined){TopicTags = '<span style="color:#337ab7"  ><i class="fa fa-tags" aria-hidden="true"></i> <span class="sr-only" >Tags</span>'+$(this).attr("ows_Tags")+'</span>'}
                                                       var TopicSubscriptions = '<button type="button" class="btn btn-link"><i class="fa fa-rss" aria-hidden="true"></i> Subscribe</button>'
                                                       var TempleteContent ='';
                                                       var TopicTabs ="";
                                                       var imageWrap ="";
                                                       var fileWrap ="";
                                                       var TemplateInstructions = $(this).attr("ows_Instructions"); if(TemplateInstructions == undefined){TemplateInstructions =''}


                                                        
                                                        
                                                       if(pagefilter  == 'Templates'){
                                                       
                                                       var instructionItems = TemplateInstructions.split('|')
                                                            /////spit each instruction item
                                                            var instructionCount = 0;
                                                            TemplateInstructions  =""
                                                             $.each(instructionItems , function( index, value ) {
                                                                if(value.length > 0){
                                                                 instructionCount +=1
															     TemplateInstructions += '<li class="list-group-item" instruction="'+instructionCount+'. '+value+'"><span  ><b class="primeColor ">'+instructionCount+'.</b> '+value+'</span></li>' 																			
															      }
															});


 
                                                        imageWrap ='<div id="imageWrap'+TopicID+'" class="row">'+													           
															       ' </div>'+                                                   
                                                                     '<br>'
                                                        fileWrap  = '<div id="fileWrap'+TopicID+'" class="row">'+													           
															       ' </div>'+                                                   
                                                                     '<br>'
            

 
                                                       
                                                        TopicTabs ='<ul class="nav nav-tabs">'+
                                                         '<li class="nav-item">'+
																		    '<a class="nav-link nav-templink active waves-effect  not-smooth" data-toggle="tab" href="#Template'+TopicID+'-panel1" role="tab" aria-controls="Template'+TopicID+'-panel1" aria-selected="true">Download</a>'+
																		  '</li>'+

																		  '<li class="nav-item">'+
																		    '<a class="nav-link nav-templink waves-effect  not-smooth"  data-toggle="tab" href="#Template'+TopicID+'-panel2" role="tab" aria-controls="Template'+TopicID+'-panel2" aria-selected="false">Instructions</a>'+
																		  '</li>'+
																		  //'<li class="nav-item">'+
																		   // '<a class="nav-link nav-templink waves-effect  not-smooth"  data-toggle="tab" href="#Template'+TopicID+'-panel3" role="tab" aria-controls="Template'+TopicID+'-panel3" aria-selected="false">Notes</a>'+
																		 // '</li>'+
																		  '<li class="nav-item">'+
																		    '<a class="nav-link nav-templink waves-effect  not-smooth" data-toggle="tab" href="#Template'+TopicID+'-panel4" role="tab" aria-controls="Template'+TopicID+'-panel4" aria-selected="false">Template Files</a>'+
																		  '</li>'+
																		  '<li class="nav-item">'+
																		    '<a class="nav-link nav-templink waves-effect  not-smooth" data-toggle="tab" href="#Template'+TopicID+'-panel5" role="tab" aria-controls="Template'+TopicID+'-panel5" aria-selected="false">Screenshots</a>'+
																		  '</li>'+
																		  
																		'</ul>'
																		var zipfunc = "'"+TopicID+"','"+TopicTitle +"'"	
														TempleteContent = TopicTabs+														                       
																		'<div class="card text-center">'+
																		  
																		  '<div class="card-body">'+
																		    '<div class="tab-content">'+
																		    '<div class="tab-pane fade in show active" id="Template'+TopicID+'-panel1" role="tabpanel">'+
																				       
																				         '<h3 class="card-title">'+TopicTitle +' (zip file) </h3>'+
																		        '<p class="card-text">Click the button below to download all template files.</p>'+
																		        '<button   onclick="zipFiles('+zipfunc+')" type="button" class="btn btn-primary waves-effect not-smooth"><i class="fa fa-arrow-down" aria-hidden="true"></i> Download <span class="sr-only">'+TopicTitle+'</span></button>'+
																				         
																				   ' </div>'+
																		        '<div class="tab-pane fade" id="Template'+TopicID+'-panel2" role="tabpanel">'+
																		        '<h3 class="card-title">'+TopicTitle +' Instructions </h3>'+

																				       '<ul id="Template'+TopicID+'-instructions" class="list-group list instruction-list list-group-flush">'+
																							TemplateInstructions+
																							'</ul>'+
																				   ' </div>'+
																				  
																				   '<div class="tab-pane fade" id="Template'+TopicID+'-panel4" role="tabpanel">'+
																				   '<h3 class="card-title">'+TopicTitle +' Attachments</h3>'+
																				   '<p class="card-text">Use this menu to download individual template files.</p>'+
																				   fileWrap  +																		        
																				
																				   ' </div>'+
																				   '<div class="tab-pane fade" id="Template'+TopicID+'-panel5" role="tabpanel">'+
																				     imageWrap +
																				
																				   ' </div>'+




																				'</div>'+    

																		    '</div>'+
																		'</div>'
																		
																		}
																		 			

    
 

                                                      
                                                       $('#sidebar').append('<li class="nav-item "  id="SAUCETopic'+TopicID+'-Li"><a type="button"  class="leftnav-topic  primeColor nav-link " href="#SAUCETopic'+TopicID+'"><b>'+TopicTitle+'</b></a></li>');
                                                       
                                                       //set topic header 
                                                       $('#Page-Content').append('<h2 id="SAUCETopic'+TopicID+'" class="page-header primeColor " >'+TopicTitle +'</a></h2>')
                                                       // Set Description
                                                        $('#Page-Content').append('<div class="lead topictext" >'+TopicDescription+'</div>'+
                                                                                  '<div class="topictext" id="SAUCETopic'+TopicID+'-html" >'+TopicHTML+'</div>'+
                                                                                     TopicSubscriptions +
                                                                                     TopicTags+                                                                                     
                                                                                     TempleteContent+
                                                                                     '<div id="SAUCETopic'+TopicID+'-SubWrap"></div>'
                                                                                     )                                                                                                                                                                   
                                                                                   
                                                                                   
                                                                                   
                                                        
                                                       if(pagefilter  == 'Templates'){       
												            //////get Template attachments
												                   getTemplateAttachments(TopicID);
												                   //////get Template 
												                  getTemplate(TopicID);
												                   
												                  
												                  }
												 
												 ////////        
												                                                       
                                                       
                                                       
                                                       
                                    })
                                      }
                                   })  
                    //////////End SpServcies
                     $('#Page-Content').append('<br><br><br>')
           
   }////////////////////////////////////////////
////////get SAUCE Sube Topics
   function  getSAUCE_SubTopics(){
     
       var SubtopicArray =[]
           var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+ 
                             "<FieldRef Name='ID' />"+ 
                             "<FieldRef Name='Description' />"+ 
                             "<FieldRef Name='Topic' />"+
                             "<FieldRef Name='HTML' />"+  
                             "<FieldRef Name='Source_x0020_Code' />"+
                             "<FieldRef Name='Note' />"+                                                            
                              "</ViewFields>"
 
         
                  ////////////////SPServices Get List Items Office Directory
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: "SAUCE Posts",
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query><Where><IsNotNull><FieldRef Name="Topic"/></IsNotNull></Where><OrderBy><FieldRef Name="Title" Ascending="False" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                                                                                                                                                                                                                                                                                                                                                     
                                                       var TopicTitle = $(this).attr("ows_Title");
                                                       var TopicID = $(this).attr("ows_ID");
                                                       var TopicDescription = $(this).attr("ows_Description");
                                                           if(TopicDescription === undefined){TopicDescription =''
                                                           }else{
                                                              TopicDescription  = ckVal_ConvertedBack($(this).attr("ows_Description"));

                                                           }
                                                       var TopicHtml = $(this).attr("ows_HTML");
                                                           if(TopicHtml === undefined){TopicHtml =''};
                                                       var SourceCode ="";
                                                       var TopicParent = 'SAUCETopic'+$(this).attr("ows_Topic").substring(0,$(this).attr("ows_Topic").indexOf(';'));
                                                       var TopicParentLI =TopicParent+'-Li'
                                                       var TopicParentUL =TopicParent+'-Ul'
                                                       var PostHtml= $(this).attr("ows_HTML");
                                                       var SourceCodeDisplay ="";
                                                       var SourceCodeHtml=""; 
                                                       var PostNote = '';
                                                       var PostPanel ='<ul class="nav nav-tabs">'+
                                                         '<li class="nav-item">'+
																		    '<a class="nav-link nav-templink active waves-effect  not-smooth" data-toggle="tab" href="#Template'+TopicID+'-panel1" role="tab" aria-controls="Template'+TopicID+'-panel1" aria-selected="true">Download</a>'+
																		  '</li>'+

																		  '<li class="nav-item">'+
																		    '<a class="nav-link nav-templink waves-effect  not-smooth"  data-toggle="tab" href="#Template'+TopicID+'-panel2" role="tab" aria-controls="Template'+TopicID+'-panel2" aria-selected="false">Instructions</a>'+
																		  '</li>'+
																		  //'<li class="nav-item">'+
																		   // '<a class="nav-link nav-templink waves-effect  not-smooth"  data-toggle="tab" href="#Template'+TopicID+'-panel3" role="tab" aria-controls="Template'+TopicID+'-panel3" aria-selected="false">Notes</a>'+
																		 // '</li>'+
																		  '<li class="nav-item">'+
																		    '<a class="nav-link nav-templink waves-effect  not-smooth" data-toggle="tab" href="#Template'+TopicID+'-panel4" role="tab" aria-controls="Template'+TopicID+'-panel4" aria-selected="false">Template Files</a>'+
																		  '</li>'+
																		  '<li class="nav-item">'+
																		    '<a class="nav-link nav-templink waves-effect  not-smooth" data-toggle="tab" href="#Template'+TopicID+'-panel5" role="tab" aria-controls="Template'+TopicID+'-panel5" aria-selected="false">Screenshots</a>'+
																		  '</li>'+																		  
																		'</ul>'

                                                     
                                                          if( $(this).attr("ows_Note") !=undefined){
                                                           PostNote = '<div class="bs-callout bs-callout-danger" ><b class="primeColor">TIP</b><p>'+$(this).attr("ows_Note")+'</p></div>'
                                                           }
                                                       
                                                        
                                                        //////set page filter changes
                                                          if(pagefilter == 'SDK'){
                                                          SourceCode = $(this).attr("ows_Source_x0020_Code");
                                                          SourceCodeHtml = $(this).attr("ows_Source_x0020_Code")

                                                             if(SourceCode === undefined){SourceCode =''};
                                                             if(SourceCode != undefined){
                                                             SourceCode = SourceCode.replace(/</g,"&#60;").replace(/>/g,"&#62;");
                                                             
                                                             SourceCodeDisplay =
                                                                '<div class="code-sample">'+
																	// '<div id="iframe'+TopicID+'-wrap">'+
																	// '<iframe id="SDK'+TopicID+'-Iframe" src="Console-Html.aspx" style="max-height:2500px;overflow:auto"  frameborder="0"  width="100%" title="SAUCE Code Results"/> '+
																	// '</div>'+
																      '<pre  ><code class="language-markup" > '+
																       SourceCode+																       
																 '</code></pre></div>'+
																 '<a href="console.aspx?tryid=23" target="_blank" type="button" class="btn btn-primary waves-effect"><span aria-hidden="true">Try It Yourself  <i class="fa fa-code" aria-hidden="true"></i></span><span class="sr-only">Try the '+TopicTitle+' Code</span></a>'
                                                             
                                                             
                                                                    };
                                                                   
                                                          } 
                                                        
                                                       //create sub topic grouping
                                                        if(jQuery.inArray(TopicParent, SubtopicArray) !== -1){
                                                        }else{
                                                        //push subtopic to array
                                                       
                                                       SubtopicArray.push(TopicParent);
                                                     //append group
                                                           $('#'+TopicParentLI).append('<ul id="'+TopicParentUL+'" class="nav flex-column">'+
                                                              '</ul>')
                                                        }
                                                        
                                                       //set side bar link
                                                       $('#'+TopicParentUL).prepend('<li class="sidebarsub nav-item" ><a type="button" class="primeColor2 leftnav-post nav-link" href="#SAUCE-SubTopic'+TopicID+'">'+TopicTitle+'</a></li>')
                                                       //set topic header 
                                                       $('#'+TopicParent+'-SubWrap').prepend('<h3 id="SAUCE-SubTopic'+TopicID+'" class="subpage-header"  >'+TopicTitle +'</a></h3>')
                                                       // Set Description Source Code and Notes
                                                       $('<p class="lead" >'+TopicDescription+'</p><p class="lead">'+TopicHtml+'</p><p>'+
                                                       PostNote+
                                                       SourceCodeDisplay+
                                                       '</p>'+
                                                        
                                                      
                                                       '<div id="knowledgeFiles'+TopicID+'" class="col-lg-12">'+
                                                       '<div class="card">'+
                                                        
															    '<ul class="list-group list-group-flush">'+
															    '</ul>'+
															'</div>'+
															'</div><br>'+
															 '<h4 class="sr-only"> '+TopicTitle+'  Attachments</h4>'+
															 '<div class="row" id="knowledgeImages'+TopicID+'" ></div>'

															  ).insertAfter('#SAUCE-SubTopic'+TopicID)
                                                    
                                                 //////display html for SDK Page      
                                             if(pagefilter == 'SDK'&& SourceCode !==''){
                                                 
                                             // setSDKIframe(TopicID,SourceCodeHtml);
                                            
                                             }else if(pagefilter == 'knowledge'){
                                                               getknowledgeAttachments(TopicID )
                                                            } 
                                                        //////////////     
                                             //////////////////////////////////////////      
                                    })
                                      }
                                   })  
                    //////////End SpServcies
 ///re=apply prism styling
       if(pagefilter == 'SDK'){
          Prism.highlightAll();
       }
 //
  ///re materialize styling
 //  $.material.init()    
     
 ////////  
   }////////////////////////////////////////////
////////
///////////Apply Page theme
 function setPageTheme(theme){
       //////////////////////////////////////
       pagefilter = theme;
       ///if Knowledge Base
        if(theme == 'knowledge'){ 
               ////set Page Details
                  ////set Page Details
                  $('#top-nav').addClass('navbar-dark blue darken-3')

                  ///make link active
                  $('#knowledge-link').addClass('active');
                  
                  ///set Primary Color
                  primecolorCode = '#1565c0'
                    $('.primeColor').css('color',primecolorCode );
                    $('.primeColor2').css('color','black')     
 
		
                }else if(theme == 'Templates'){ ///if Templates
      
                ////set Page Details
                  ////set Page Details
                  $('#top-nav').addClass('red darken-2')

                  ///make link active
                  $('#templates-link').addClass('active');
                  
                  ///set Primary Color
                  primecolorCode = '#d32f2f'
                    $('.primeColor').css('color',primecolorCode );
                    $('.primeColor2').css('color','black')     
 

                }else if(theme == 'SDK'){ ///if SDK
             ////set Page Details
                  ////set Page Details
                  $('#top-nav').addClass('purple darken-2')

                  ///make link active
                  $('#sdk-link').addClass('active');
                  
                  ///set Primary Color
                  primecolorCode = '#8e24aa'
                    $('.primeColor').css('color',primecolorCode );
                    $('.primeColor2').css('color','black')     
 

						
                }else if(theme == 'Mixer'){
               
                    ////set Page Details
                PageTitle = 'Sauce Mixer';
                PageDesc ='Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'
                PageSearch = 'test';
                ///set Instructions
                $('#main-well').html(
                '<div class="row">'+
                           '<h2 class="subbanner-Heading"><i class="fa fa-info-circle" aria-hidden="true"></i> Instructions</h2> '+
                        '<div class="col-sm-12" >'+                        
                        '<p>Rem aperiam, enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut!</p>'+
                       ' </div>'+
                   ' </div>'   )
                 //// set page layout
                 $('#page-ico').removeAttr('class').attr('class','fa fa-cutlery');	

                  $('#masthead').css('text-align','left').addClass('saucebg-post');

                  
                  ///load left Navigation
                   //setNewPostNav()
                }else if(theme == 'Home'){
                  ////set Page Details
                  $('#top-nav').addClass('navbar-dark light-blue darken-3')
                  $('#Home-link').addClass('active')
                }
              
                //setHtml
                //  $('#PageWelcometxt').addClass('HomeWelcome-txt')
                //  $('.PageSubject').append(PageTitle);
                //  $('.sidebarPage-Link.PageSubject').attr('href',currnentAspx()).html(PageTitle)
               //   $('.PageDescription').html(PageDesc)
                //  $(PageSearch).insertAfter('.PageDescription')
             ////////////////////////
                                         
 
 
 };
////////////////////////////////////////////

/////Cancel Refresh Link
function refreshPage(){
    
     ///reomve extra parameters
      if(window.location.href.indexOf('#') >= 0){
       ///Redirect Page
       var redirectLink = window.location.href.substring(0,window.location.href.indexOf('#'))      
         window.location.href = redirectLink 
         
      }else{
       ///Redirect Page      
       window.location.href = window.location.href
      }
  // 

};
/////////////////////// 
////////////////remove left nav

















//////////////////////////////////////////////
/////Cancel Refresh Link
function refreshPage(){
    
     ///reomve extra parameters
      if(window.location.href.indexOf('#') >= 0){
       ///Redirect Page
       var redirectLink = window.location.href.substring(0,window.location.href.indexOf('#'))      
         window.location.href = redirectLink 
         
      }else{
       ///Redirect Page      
       window.location.href = window.location.href
      }
  // 

};
/////////////////////// 
 ////get and set Selectable options
 function setSelections(targetInput,targetList ){
       ////empty dropdown
        $(targetInput +'> .Sp-Selectable').remove()
      /////get all Approval Types
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+
                             "<FieldRef Name='ID' />"+                                                           
                              "</ViewFields>"
 
                  ////////////////SPServices Get List Items 
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: targetList,
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query><OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                      
                                   //////set selectable options
                                   $(targetInput).append('<option class="Sp-Selectable" value="'+$(this).attr("ows_ID")+'">'+$(this).attr("ows_Title")+'</option>');                                                                                                                                                                                                                                                                                                                               
                                   //////////////////////////////////////////                                    
                                    })
                                      }
                                   })  
                    //////////End SpServcies Get List Items 
                    
                    
 }
 /////////////////////////////////////////////////
//////////////////////set Universal Combo
function setCombox(spList,comboOption){

   /////get all offices
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+
                             "<FieldRef Name='ID' />"+                                                           
                              "</ViewFields>"
 
                  ////////////////SPServices Get List Items Office Directory
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: spList,
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query><OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                                                                                                                                                                                                                                                                                                                                                     
                                     comboOption.push($(this).attr("ows_Name"));
                                   //  selectableOfficesValues.push($(this).attr("ows_ID"));
                                                   
                                                                       
                                    })
                                      }
                                   })  
                    //////////End SpServcies get all offices



}

/////////////////////////////////////////////////////////////////////

//////////////////////set Universal Combo
function setCombo(spList){
     var comboOptions ='';
   /////get all offices
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+
                             "<FieldRef Name='ID' />"+                                                           
                              "</ViewFields>"
 
                  ////////////////SPServices Get List Items 
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: spList,
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query><OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                                                                                                                                                                                                                                                                                                                                                     
                                     comboOptions += '<option value="'+$(this).attr("ows_ID")+'" >'+$(this).attr("ows_Title")+'</option>';
                                   //  selectableOfficesValues.push($(this).attr("ows_ID"));
                                                   
                                                                       
                                    })
                                      }
                                   })  
                    //////////End SpServcies get List items

    return comboOptions

}

/////////////////////////////////////////////////////////////////////

//////////////////////set Universal Combo
function setComboTags(spList){
     var comboOptions ='';
     var option1 =  '<optgroup label="Knowledge Base">'
					   
     var option2 = '<optgroup label="SDK">'
							   
							  
     var option3 =  '<optgroup label="Template">'
                                   
   /////get all offices
       var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+
                             "<FieldRef Name='ID' />"+
                             "<FieldRef Name='Page' />"+                                                           
                              "</ViewFields>" 
                              //2;#Adhdhdh;#13;#dgdgdg
 
                  ////////////////SPServices Get List Items 
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: spList,
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query><Where><Eq><FieldRef Name="Status"/><Value Type="Text">Approved</Value></Eq></Where><OrderBy><FieldRef Name="Title" Ascending="True" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                              var comboPage = $(this).attr("ows_Page").substring(2,$(this).attr("ows_Page").lastIndexOf(";"));
                                 if(comboPage =='Knowledge Base'){
                                        option1 += '<option value=";#'+$(this).attr("ows_ID")+';#'+$(this).attr("ows_Title")+'" >'+$(this).attr("ows_Title")+'</option>'; 
                                       
                                 }else if(comboPage =='SDK'){
                                         option2 += '<option value=";#'+$(this).attr("ows_ID")+';#'+$(this).attr("ows_Title")+'" >'+$(this).attr("ows_Title")+'</option>';
                                 
                                 }else if(comboPage =='Templates'){
                                          option3 += '<option value=";#'+$(this).attr("ows_ID")+';#'+$(this).attr("ows_Title")+'" >'+$(this).attr("ows_Title")+'</option>';
                                 
                                 };
                                  

                                //////////////////////////////////////////////////////              
                                    })
                                      }
                                   })  
                    //////////End SpServcies get List items
                    
                    ///////////////set option groups
                        option1 +=  '</optgroup >'
                        option2 += '</optgroup>'
                        option3 +=  '</optgroup >'
                        
                       
                        comboOptions = option1+option2+option3
  
    return comboOptions

}

/////////////////////////////////////////////////////////////////////
 //////get ck editor Values
 var ckVal_Html = function(ckInput){///HTML
 ///////////DO Not use ID #
     var OriginalHtml = CKEDITOR.instances[ckInput].getData() ; 
     var SPSavebleHtml = OriginalHtml.replace(/</g,"&lt;").replace(/>/g,"&gt;");
  return SPSavebleHtml 
 
 };
 var ckVal_Text = function(ckInput){////Text
 ///////////DO Not use ID #
     var OriginalText = CKEDITOR.instances[ckInput].document.getBody().getText() ; 
  return OriginalText ; 
 
 };
 var ckVal_ConvertedBack = function(htmlValue){////Text

		 if(htmlValue !== undefined){
		     var newText = htmlValue.replace(/&lt;/g,"<").replace(/&gt;/g,">") ;
		         newText = newText.replace(/xxz</g,"&lt;").replace(/>yyz/g,"&gt;") ; 
 
		  return newText  ; 
		  }
 
 }
////////close uploader modal
function closeModalUploader(){
     ///close uploader well
      $('#MixerUploader').collapse('hide');

}
////////Uplodoad Successful
function UploadSucessful(DocumentLibraryName ){
     //////////Post Vulcan Alert
			alert('saved');
///// refresh 
if(DocumentLibraryName == 'SAUCE Attachments' ){
       getAttachmentFiles('SAUCE Attachments','Attachment_'+saucePostID )
     }else if(DocumentLibraryName == 'SAUCE Templates' ){
       getAttachmentFiles('SAUCE Templates','Template_'+saucePostID )

     }
 //// close uploader modal
   closeModalUploader()

}  
 function scrollFunction() { 
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("topBtn").style.display = "block";
    } else {
        document.getElementById("topBtn").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}/////////////////////////////////////////////////////////////////////////////

function downloadAll(urls) {
  var link = document.createElement('a');

  link.setAttribute('download', null);
  link.style.display = 'none';

  document.body.appendChild(link);

  for (var i = 0; i < urls.length; i++) {
   link.setAttribute('href', urls[i]);
   alert( urls[i])
   // link.setAttribute('download',filename)
    link.click();
   // alert(link)
  }

 // document.body.removeChild(link);
}

//////////
function stylizeTable(bootstrapTableID){
  ////add to table
   $('#'+bootstrapTableID).DataTable();
  ///convert serach input
  

   ///convert buttons
     $('#'+bootstrapTableID+'_paginate > span > .paginate_button').addClass('btn btn-secondary  waves-effect btn-sm').removeClass('paginate_button')
     $('#'+bootstrapTableID+'_paginate > span > .current').addClass('active');
      //prev and next button
        $('#'+bootstrapTableID+'_paginate > .paginate_button').addClass('btn btn-flat  waves-effect btn-sm').removeClass('paginate_button previous next');
      //click event
       $('#'+bootstrapTableID).on( 'draw.dt', function () {
			    ///convert buttons
				     $('#'+bootstrapTableID+'_paginate > span > .paginate_button').addClass('btn btn-secondary  waves-effect btn-sm').removeClass('paginate_button')
				     $('#'+bootstrapTableID+'_paginate > span > .current').addClass('active');
				     //prev and next button
        $('#'+bootstrapTableID+'_paginate > .paginate_button').addClass('btn btn-flat waves-effect btn-sm').removeClass('paginate_button previous next');
         });
     
   ///convert search input
   ////add new label
   var serachInputID= bootstrapTableID+'_SearchInput'   
   
   ///update input
     $('#'+bootstrapTableID+'_filter > label > input').unwrap().attr('id',serachInputID).addClass('form-control').removeAttr('placeholder')
     var inputHtml =$('#'+bootstrapTableID+'_filter > input').detach();
   ///empty filter div
     $('#'+bootstrapTableID+'_filter').empty().append( '<div id="'+serachInputID+'_wrap" class="md-form"></div>')
   ///append input
     inputHtml.appendTo( "#"+serachInputID+"_wrap" );
     //append new lavel
     $("#"+serachInputID+"_wrap").append('<label for="'+serachInputID+'" >Search</label><br>')
}
//////////////

