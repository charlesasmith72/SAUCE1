﻿ 


$('document').ready(function(){
        /// Apply Page theme
           setPageTheme('Mixer');
                                                                          
          /* activate scrollspy menu */
var $body   = $(document.body);
var navHeight = $('.navbar').outerHeight(true) + 10;

$body.scrollspy({
	target: '#leftCol2',
	offset: navHeight
});
/* smooth scrolling sections */
$('.wizrd-link > a[href*="#"]').not('a[href="#"]').click(function() {
    //set active link
    $(this).parent('li').addClass('wizrd-link-active')

    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
      if (target.length) {
        $('html,body').animate({
          scrollTop: target.offset().top - 50
        }, 1000);
        return false;
      }
    }
});

            
            /////apply page styling 
            ///set Primary Color
                    $('.primeColor').css('color','#0072bc');
                    $('.primeColor2').css('color','black') ;
              
                 $('#leftCol').remove();
                 
                 $('#contentrow').addClass('contentrow-mixer')
             /* activate sidebar */
				//$('#sidebar-right').affix({
				//  offset: {
				//    top: 235
				  //}
				//});
				 $('div[data-toggle="popover"]').hover(
				 	
						 function() {
						  var parentDiv = $(this).attr('id');  					
					      $('#'+parentDiv ).children( ".mixeredit-btn" ).show()					
						 },
						   function() {
						  var parentDiv = $(this).attr('id');						
						    $('#'+parentDiv ).children( ".mixeredit-btn" ).hide()					
						 }

						);

             
        
          
         if(saucePostID > 0 || sauceTopicID > 0){
         
         
         }else{//////launch getting started
            // OpenSauceEditor('New','Details')
         
         }
          
        //
        // When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};


////////////////activate link
      // resetSAUCEPost()

})

//////////////////////////////////////////////////////////////////////////////////
/////////////Open Mixer Modal
function OpenSauceEditor(saveFunction,mixerMode){

var MixerModal = saveFunction;
    saveFunction ='';
var footerButtons = '';
var formHtml ='';


if(mixerMode == 'Details' ){
 var saveFunction = "saveDetails('New')";
//var saveFunction = "saveDetails('Update')"
      footerButtons = '<button type="button" onclick="'+saveFunction+'" class="btn btn-success btn-lg btn-block">Save</button>'+
                    '<button type="button" data-dismiss="modal" aria-label="Close" class="btn btn-default btn-lg btn-block">Cancel</button>'

      
/////////Details and Description 
  formHtml = '<h3>Details and Description</h3>'+
                     '<div class="alert alert-warning" role="alert">'+
						'<p><i class="fa fa-info-circle" aria-hidden="true"></i>'+
						' <span class="sr-only">Details and Description Instructions</span>'+
					    'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut , sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt</p></div>'+
                     '<form>'+
                       '<div class="panel-body">'+
		               '<div class="form-group">'+
		               '<label  for="TitleInput">Title </label>'+
					   ' <input     style="" type="text" class="form-control" id="TitleInput"  placeholder="Title"  aria-required="true" />'+ 				    
					  '</div>'+
					   
					  '<div class="form-group">'+
					    '<label class=""  for="DescribeInput">Main Description</label>'+
				    '<textarea id="DescribeInput"  class="form-control" rows="7" value="" aria-required="true"> </textarea>'+
					  '</div>'+
					  
					  '<div class="form-group">'+
					    '<label class=""  for="ArticleInput">Article</label>'+
				    '<textarea id="ArticleInput"  class="form-control" rows="7" value="" aria-required="true"> </textarea>'+
					  '</div>'+
					  
					  '<fieldset class="form-group">'+
					 '<label aria-hidden="true" >Submission Type</label><br/>'+
						'<legend class="sr-only">Select your Submission Type. either'+ 
						'Topic or Post by clicking on one of the buttons</legend> '+	
						'<div  class="radio-inline">'+
						'<label >'+
						 
				         '<input onchange="" type="radio" name="SubmissionOptions"  onclick="changeSubmissionType('+"'Topic'"+')"    value="Topic"/>Topic'+
						'</label></div>'+
						'<div  class="radio-inline">'+
					     '&nbsp;<label ><input onchange="" type="radio" name="SubmissionOptions" onclick="changeSubmissionType('+"'Post'"+')"   value="Post"/>Post'+
						'</label>'+
						 '&nbsp;</div></fieldset >'+
		            '<div id="Topic-well" class="well collapse submission-well">'+
		            '<div   class="form-group ">'+
					    '<label   for="CategoryInput">Page Category</label>'+
					    '<select     id="CategoryInput" class="form-control" >'+
					              '<option value="">Select a SAUCE Page Category</option>'+
					              '<option>Knowledge Base</option>'+
					              '<option>Templates</option>'+
					              '<option>SDK</option>'+
								'</select>'+
								'</div>'+
		            '</div>'+
		            '<div id="Post-well" class="well collapse submission-well">'+
		            '<div   class="form-group ">'+
					    '<label   for="TopicInput">SAUCE Topic</label>'+
					    '<select     id="TopicInput" class="form-control" >'+
								'</select>'+
								'</div>'+
		                 '</div>'+
                    '</form>'
} else if(mixerMode == 'Attachments' ){
 //var saveFunction = "saveDetails('New')";
var saveFunction = "saveLinks()";

      footerButtons = '<div class="dropdown">'+
					 ' <button id="dLabel" type="button" class="btn btn-primary btn-lg btn-block" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">'+
					    '<i class="fa fa-plus" aria-hidden="true"></i> Add'+
					  '</button>'+
					  '<ul class="dropdown-menu" aria-labelledby="dLabel">'+
					    ' <li><a href="Javascript:showLinkForm()">Link</a></li>'+ 
					    '<li><a href="Javascript:showAttachmentForm('+"'attachment'"+')">Attachment</a></li>'+
					  '</ul>'+
					'</div> '+                  
					'<button type="button" data-dismiss="modal" aria-label="Close" class="btn btn-default btn-lg btn-block">Close</button>'


/////////Links and Attachments
var formHtml = '<h3>Links and Attachments</h3>'+
                     '<div class="alert alert-warning" role="alert">'+
						'<p><i class="fa fa-info-circle" aria-hidden="true"></i>'+
						' <span class="sr-only">Attachments Instructions</span>'+
					    'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut , sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt</p></div>'+
                     '<form>'+
                       '<div class="panel-body">'+
                       
                       
                       
		                  '<h4 style="color:#337ab7">Links</h4>'+ 
		                  	'<table summary="Attachmented Links" id="AttachmentLinksTable" class="table table-striped">'+
				            '<thead>'+
				            '<tr  >'+
				            '<th scope="col">Link</th>'+
				            '<th scope="col"><span class="sr-only">Link Options</span></th></tr>'+
						'</thead>'+
						'<tbody>'+
						        		'</tbody> '+
				         '</table>'+
  
		                  '<div id="LinkForm" class="well collapse" >'+
		                     '<div class="form-group">'+
					               '<label  for="LinkNameInput">Link Name</label>'+
								   ' <input  style="" type="text" class="form-control" id="LinkNameInput"  placeholder="Link Name"  aria-required="true" />'+ 				    
								  '</div>'+
							  '<div class="form-group">'+
					               '<label  for="LinkURLInput">URL</label>'+
								   ' <input  style="" type="text" class="form-control" id="LinkURLInput"  placeholder="URL"  aria-required="true" />'+ 				    
								  '</div>'+
								   '<button type="button" onclick="hideLinkForm()" class="btn btn-default ">Cancel</button> '+
								  '<button type="button" onclick="'+saveFunction+'" class="btn btn-success ">Save</button>'+	  
		                  '</div>'+ 
                          '<h4 style="color:#337ab7">Attachments</h4>'+
								'<table summary="Attachment Files" id="AttachmentTable" class="table table-striped">'+
				            '<thead>'+
				            '<tr  >'+
				            '<th scope="col">Name</th>'+
				            '<th scope="col">Upload Date</th>'+
				            '<th scope="col"><span class="sr-only">Attachment Options</span></th></tr>'+
						'</thead>'+
						'<tbody>'+
						
				            		'</tbody> '+
				         '</table>'+
				         '<div id="MixerUploader" class="well collapse" >hello!</div>'+
                 	
               '</div>'+
        '</form>'
} else if(mixerMode == 'Source Code' ){

var saveFunction = "saveSourceCode('Update')";
      footerButtons = '<button type="button" onclick="'+saveFunction+'" class="btn btn-success btn-lg btn-block">Save</button>'+
                    '<button type="button" data-dismiss="modal" aria-label="Close" class="btn btn-default btn-lg btn-block">Cancel</button>'


/////////Details and Description 
var formHtml = '<h3>Source Code</h3>'+
                     '<div class="alert alert-warning" role="alert">'+
						'<p><i class="fa fa-info-circle" aria-hidden="true"></i>'+
						' <span class="sr-only">Source Code Instructions</span>'+
					    'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut , sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt</p></div>'+
                     '<form>'+
                       '<div class="panel-body">'+
		                     '<div id="code-wrap"  >'+
								'<pre class="code" style="min-height: 200px"  data-language="html">'+
                         		'</pre>'+
								'</div>'+ 
								'<div class="btn-group" role="group" aria-label="...">'+
								//'<button id="editCodeBtn" type="button"  onclick="editCode()" class="btn btn-primary btn-lg"  href="#"><i aria-hidden="true" class="glyphicon glyphicon-pencil"></i>'+ 
								//'Edit Code </button>'+
								'<button onclick="runCode()" style="display:none"  class="btn btn-primary btn-lg"  ><i aria-hidden="true" class="glyphicon glyphicon-play"></i> '+
								'Preview Code </button>'+
								'</div>'+

								                 	
               '</div>'+
        '</form>'
}else if(mixerMode == 'Plugins' ){
 
 var saveFunction = "saveInstructions('Update')";
      footerButtons ='<button type="button" onclick="showAttachmentForm('+"'template'"+')" class="btn btn-primary btn-lg btn-block">Upload</button>'+ 
                    '<button type="button" onclick="'+saveFunction+'" class="btn btn-success btn-lg btn-block">Save</button>'+
                    '<button type="button" data-dismiss="modal" aria-label="Close" class="btn btn-default btn-lg btn-block">Cancel</button>'


///////// Plugins and Template
var formHtml = '<h3>Plugins and Templates</h3>'+
                     '<div class="alert alert-warning" role="alert">'+
						'<p><i class="fa fa-info-circle" aria-hidden="true"></i>'+
						' <span class="sr-only">Plugin and Template Instructions</span>'+
					    'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut , sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt</p></div>'+
                     '<form>'+
                       '<div class="panel-body">'+
		
				'<div class="form-group">'+
			    '<label class=""  for="InstructionInput">Instructions</label>'+
		    '<textarea id="InstructionInput"  class="form-control" rows="7" value="" aria-required="true"> </textarea>'+
			  '</div>'+
                     '<div id="MixerUploader" class="collapse well" ></div>'+
				'<table summary="Table Description" id="TemplateTable" class="table table-striped">'+
            '<thead>'+
            '<tr  >'+
            '<th scope="col">Name</th>'+
            '<th scope="col">Upload Date</th>'+
            '<th scope="col"><span class="sr-only">Template Attachment Options</span></th></tr>'+
		'</thead>'+
		'<tbody>'+
		'<tr>'+
	      '<td scope="row"><a href="#">SP list fix</a></td>	'+
	      '<td>11/9/2017</td>'+
	      '<td><button type="button" class="btn btn-danger">Delete</button></td>'+
		'</tr>'+
		'<tr>'+
	      '<td scope="row"><a href="#">Infopath FIx</a></td>'+	
	     ' <td>11/9/2017</td>'+
	      '<td><button type="button" class="btn btn-danger">Delete</button></td>'+
		'</tr>'+
            		'</tbody> '+
         '</table>'+
         
               
                 	
               '</div>'+
        '</form>'
}else if(mixerMode == 'Tags' ){
  
 var saveFunction = "saveTags('Update')";
      footerButtons ='<button type="button" onclick="'+saveFunction+'" class="btn btn-success btn-lg btn-block">Save</button>'+
                    '<button type="button" data-dismiss="modal" aria-label="Close" class="btn btn-default btn-lg btn-block">Cancel</button>'
      var topicOption =  setComboTags('SAUCE Topics');

///////// Plugins and Template
var formHtml = '<h3>Tags and Notes</h3>'+
                     '<div class="alert alert-warning" role="alert">'+
						'<p><i class="fa fa-info-circle" aria-hidden="true"></i>'+
						' <span class="sr-only">Tags and Notes Instructions</span>'+
					    'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut , sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt</p></div>'+
                     '<form>'+
                     
		
							'<div class="panel-body">'+
							'<div class="form-group">'+
						   ' <label class=""  for="TagsInput">Tags</label>'+
					    '<select class="js-example-basic-multiple form-control" style="width:100%" id="TagsInput" name="Tags[]" multiple="multiple">'+
							 
                              topicOption +
							'</select>'+
							
						  '</div>'+

							'<div class="form-group">'+
						   ' <label class=""  for="NotesInput">Notes and Tips</label>'+
					    '<textarea id="NotesInput"  class="form-control" rows="7" value="" aria-required="true"> </textarea>'+
						  '</div>'+
                        '</div>'+
        '</form>'
}







////////////////////Configure Modal
var Modal_ID = 'Mixer1';
 var Modal_Context= 'Details and Description'
 var Modal_Title = 'SAUCE Editor';
 var Modal_TitleIcon = '<i class="fa fa-cogs" aria-hidden="true"></i>';
 var Modal_Body =  formHtml                
		
 var DocPropertiesModal = '<div class="modal fade" id="'+Modal_ID+'" tabindex="-1" role="dialog" aria-labelledby="'+Modal_ID+'Label">'+
  '<div class="modal-dialog modal-lg role="form">'+
    '<div class="modal-content">'+
      '<div class="modal-header">'+
        '<button style="color:white" type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>'+
        '<h2 class="modal-title" id="'+Modal_ID+'Label"> <span style="">'+Modal_TitleIcon+' '+Modal_Title+'</span></h2>'+
     ' </div>'+
     '<div class="modal-wrap">'+
      '<div class="modal-body" style="">'+
        Modal_Body+
      '</div>'+
      '<div class="modal-footer">'+
        footerButtons+
      '</div>'+
      '</div>'+
    '</div>'+
  '</div>'+
'</div>'
  //append Modal to the Page Body
       ////remove m0dal
 $('#'+Modal_ID).remove()
  $('body').append(DocPropertiesModal) ;
  /////append to mixer
     // $('#Page-Content').append(formHtml)

if(mixerMode == 'Details'){
    ////set Topic dropdown
   var topicOption =  setCombo('SAUCE Topics');
   $('#TopicInput').append('<option value="">Select a SAUCE Topic</option>'+
                 topicOption 
              );
   CKEDITOR.replace( 'DescribeInput' ); 
   CKEDITOR.replace( 'ArticleInput' );
    ////default mode cancel button  location.href=location.href
     
    }else if(mixerMode == 'Tags'){         
             
        CKEDITOR.replace( 'NotesInput' );       
   //$('#TagsInput').append(topicOption);

    $('.js-example-basic-multiple').select2();
    }else if(mixerMode == 'Source Code'){         
        
    $('#code-wrap > pre.code').highlight({source:1, zebra:1, indent:'space', list:'ol',attribute: 'data-language'});
    editCode()
    }else if(mixerMode == 'Plugins'){         
             
     CKEDITOR.replace( 'InstructionInput' );   
     
      // resetUploader('MixerUploader','SAUCE%20Templates','Template_123')
       getAttachmentFiles('SAUCE Templates','Template_'+saucePostID )

      
    }else if(mixerMode == 'Attachments'){
    
      // resetUploader('MixerUploader','SAUCE%20Attachments','Attachment_123');
       getAttachmentLink();
       getAttachmentFiles('SAUCE Attachments','Attachment_'+saucePostID )
    
    };

  //show Modal
  $('#'+Modal_ID).modal('show')

          
}

////////////////////////////////////////////////////////////////////////////////////
//////Change submission Types
function changeSubmissionType(selectedOption){
      /// hide all submission wells
      $('.submission-well').collapse('hide');
     ////show selected well  
    $('#'+selectedOption+'-well').collapse('show')

}
//////////////////////////////////////////////
//////save new Topic or Pos
    function saveDetails(saveMode){
      
    
        ////Details and Description Variables currentFormEIT_Q1 = ckVal_Html('EITStandards');
          
          var MixerItemId = ''  
          var postTitle = $('#TitleInput').val();
          var postDesc =  ckVal_Html('DescribeInput');//$('#DescribeInput').val();
          var postArticle = ckVal_Html('ArticleInput'); //$('#ArticleInput').val();
          var postSubmissionType =  $("input[name='SubmissionOptions']:checked").val();
          var postPage  =  $('#CategoryInput').val();
          var postTopic  =  $('#TopicInput').val();
           ///aet Edit ID
           if(saveMode == 'Update' && postSubmissionType == 'Topic'  ){
                  MixerItemId = sauceTopicID;
           }else if(saveMode == 'Update' && postSubmissionType == 'Post'  ){
                  MixerItemId = saucePostID; 
           }    
           
          if(postSubmissionType == 'Topic'){
             //////Save SPservices
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: saveMode,
						        ID:MixerItemId ,
						        listName: "SAUCE Topics",
						        valuepairs:  [["Title", postTitle],
						                       ["Description", postDesc],
						                       ["HTML", postArticle],
						                       ["Page", postPage],
											 ],
											
						        completefunc: function(xData, Status) {
						      
							        if(Status == 'success'){	
							        						        
							            alert('saved')
							        
							        }//////////////////////////////////////
						          
						        }
						    });
                        //////End save SPservice
          
           }else if(postSubmissionType == 'Post'){
             //////Save SPservices
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: saveMode,
						        ID:MixerItemId ,
						        listName: "SAUCE Posts",
						        valuepairs:  [["Title", postTitle],
						                      ["Description", postDesc],
						                      ["HTML", postArticle], 
						                      ["Topic", postTopic],

						                     
											 ],
											
						        completefunc: function(xData, Status) {
						      
							        if(Status == 'success'){	
							        						 
                                      var newID = $(xData.responseXML).SPFilterNode("z:row").attr("ows_ID");
							        saucePostID = newID ;
       
							            alert('saved');
							            ////Create folder
							                //if(){
							                  createFolder('Template_'+saucePostID ,'SAUCE Templates')
							               // }else if(){
							                   createFolder('Attachment_'+saucePostID ,'SAUCE Attachments')
  
							                //}///
                                            
							        
							        }//////////////////////////////////////
						          
						        }
						    });
                        //////End save SPservice
          

          }else{
          
             alert('Error! Select a Submission Option')
          
          }
    
    
    
    
    
    }
////////////////////////////////////////////////
//////save Source COde
    function saveSourceCode(saveMode){
      MixerItemId  = saucePostID 
    
        ////Details and Description Variables
          var currentCodeView = "code" 
			   if($( "#code-wrap > div > .tabs > li.code" ).hasClass( "active" )){
			     currentCodeView = "code"
			   }else if($( "#code-wrap > div > .tabs > li.source" ).hasClass( "active" )){
			     currentCodeView = "source"
			   }
		var newSourceCode ="";
			if(currentCodeView == "code"){
			     newSourceCode =  $('#code-wrap > div > pre.code').text().replace(/</g,"&#60;").replace(/>/g,"&#62;");
			    }else if(currentCodeView == "source"){
			     newSourceCode =  $('#code-wrap > div > pre.source').text().replace(/</g,"&#60;").replace(/>/g,"&#62;");
			    }

             //////Save SPservices
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: saveMode,
						        ID:MixerItemId ,
						        listName: "SAUCE Posts",
						        valuepairs:  [["Source_x0020_Code", newSourceCode ],
											 ],
											
						        completefunc: function(xData, Status) {
						      
							        if(Status == 'success'){	
							        						        
							            alert('saved')
							        
							        }//////////////////////////////////////
						          
						        }
						    });
                        //////End save SPservice
          
     
    
    
    
    }
////////////////////////////////////////////////
//////save Instructions
    function saveInstructions(saveMode){
      MixerItemId  = saucePostID 
    
        ////Details and Description Variables
          var postInstructions = ckVal_Html('InstructionInput');  ///$('#InstructionInput').val();
             //////Save SPservices
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: saveMode,
						        ID:MixerItemId ,
						        listName: "SAUCE Posts",
						        valuepairs:  [["Instructions", postInstructions],
											 ],
											
						        completefunc: function(xData, Status) {
						      
							        if(Status == 'success'){	
							        						        
							            alert('saved')
							        
							        }//////////////////////////////////////
						          
						        }
						    });
                        //////End save SPservice
          
     
    
    
    
    }
////////////////////////////////////////////////
//////save Instructions
    function saveTags(saveMode){
      MixerItemId  = saucePostID 
    
        ////  Variables
          var postNotes = ckVal_Html('NotesInput'); // $('#InstructionInput').val();
          var postTags ='';
           $('#TagsInput option:selected').each(function(){postTags += $(this).val()});
              postTags = postTags.substring(postTags.indexOf(';'))   
             //////Save SPservices
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: saveMode,
						        ID:MixerItemId ,
						        listName: "SAUCE Posts",
						        valuepairs:  [["Note", postNotes ],
						                      ["Tagged_x0020_Topics",postTags],
											 ],
											
						        completefunc: function(xData, Status) {
						      
							        if(Status == 'success'){	
							        						        
							            alert('saved')
							        
							        }//////////////////////////////////////
						          
						        }
						    });
                        //////End save SPservice
          
     
    
    
    
    }
////////////////////////////////////////////////
/////Reset Uploader
function resetUploader(selectorUsed,attachmentLibrary,attachmentFolder){
//var SelectAttachment_Value = $('#'+selectorUsed).val();
var IframeWrap = selectorUsed;

    ///// Remove/reset Iframe 
     $('#'+IframeWrap).empty()
//if(SelectAttachment_Value !== "" && SelectAttachment_Value !== undefined ){//show iframe
    
    /////Append Iframe Uploader
     //$('#'+IframeWrap).append('<iframe width="100%"  style="height:200px;border:0px!important" src="Upload2013.aspx?libraryname='+attachmentLibrary+'&fname='+DeterminationFolder+'&attype='+SelectAttachment_Value+'"></iframe>')
          
          $('#'+IframeWrap).append('<iframe width="100%"  style="height:200px;border:0px!important" src="Upload2013.aspx?libraryname='+attachmentLibrary+'&fname='+attachmentFolder+'"></iframe>')

    
  //} 

};
///////////////////////////////////////////////////////

////Create folder
function createFolder(newFolderName,attachmentLibrary){
 
 /////Create Folder Case Attachment Documents
                        $().SPServices({
                                        operation: "UpdateListItems",
                                        async: false,
                                        listName: attachmentLibrary,
                                        batchCmd: "New",                        
			                            updates: "<Batch OnError='Continue' PreCalc='TRUE' ListVersion='0' >" +
				                                    "<Method ID='1' Cmd='New'>" +
				                                    "<Field Name='FSObjType'>1</Field>" +
				                                    "<Field Name='BaseName'>"+newFolderName+"</Field>" +
				                                    "</Method>" +
				                                    "</Batch>",
                                     completefunc: function(xData, Status) {
                                             //////If successful
                                           if(Status == 'success'){
                                           
                                          //////////Post Vulcan Alert
							         /// newAlert('#Form-Alerts',////Location
										        // 'success',////Theme
										        // 'Saved!',////Bold Alert
										        // 'Your Determination Form updates have been saved.'////Message
										        // );
									   //////////////////////////

                                           
                                              }else{
                                           //////////Post Vulcan Alert	         
										//newAlert('#Form-Alerts',////Location
										        // 'danger',////Theme
										      //   'Error!',////Bold Alert
										      //   'There was an error saving your changes.'////Message
										        // )
										////////////////////////////////////////////////// 
                                                                                                 
                                                                                                 
                                                                                                 
                                             };
                                             //////End if successful

                                         }
        
                                   });
                                 /////////////////////////////////////////////////////////
 
 
}
///////////////////////////////////////////////////////////////////
///////get Attachment Documents

function getAttachmentFiles(attachmentLibrary,attachmentFolderID){ 
       
       
     var attactmentTBL = '';  
     if(attachmentLibrary == 'SAUCE Attachments' ){
         attactmentTBL ="AttachmentTable";
     }else if(attachmentLibrary ==  'SAUCE Templates'){
         attactmentTBL ="TemplateTable";
     };
     //empty original files
     $('#'+attactmentTBL+' > tbody').empty()
   

     
         DocumentQuery = '<Query><Where><Contains><FieldRef Name="FileDirRef"/><Value Type="Text">'+attachmentFolderID+'</Value></Contains></Where><OrderBy><FieldRef Name="Created" Ascending="False" /></OrderBy></Query>'
                
    ////////////////SPServices Get List Items
                               $().SPServices({
                                        operation: "GetListItems",
                                        async: false,
                                        listName: attachmentLibrary,
                                        CAMLViewFields: "<ViewFields><FieldRef Name='ID' /><FieldRef Name='Attachment_x0020_Type_x003a_Title'/><FieldRef Name='Attachment_x0020_Type_x003a_ABRV'/><FieldRef Name='LastMOD' /><FieldRef Name='FileDirRef' /><FieldRef Name='Created' /><FieldRef Name='_SourceUrl' /><FieldRef Name='_SourceUrl' /><FieldRef Name='FileLeafRef' /><FieldRef Name='ID' /><FieldRef Name='Author' /><FieldRef Name='FileDirRef' /><FieldRef Name='DocIcon' /><FieldRef Name='FileRef' /></ViewFields>",
                                        CAMLQuery:DocumentQuery ,
                                        CAMLQueryOptions: '<QueryOptions><ViewAttributes Scope="Recursive"/></QueryOptions>',
                                        completefunc: function (xData, Status) {
                                          $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                          var Document_ID = $(this).attr("ows_ID")
                                          var Document_Name =$(this).attr("ows_FileLeafRef").substring( $(this).attr("ows_FileLeafRef").indexOf('#')+1);
                                          var Document_URL = window.location.protocol + "//" + window.location.host + "/" + $(this).attr("ows_FileDirRef").substring($(this).attr("ows_FileDirRef").indexOf('#')+1)+"/"+Document_Name;
                                          var DocumentLink = $(this).attr("ows_FileRef").substring( $(this).attr("ows_FileRef").indexOf('#')+1);
                                          var DocumentMOD =  $(this).attr("ows_LastMOD").substring( $(this).attr("ows_LastMOD").indexOf('#')+1);
                                          var Document_AttType = ''
                                          var Document_AttID ="";
                                          
                                        
                                                                             
						                                          
						 
                                ///set document icon
                                    var docicon = $(this).attr("ows_DocIcon");  
                                         if(docicon.indexOf('do') > -1){//Word Document
                                               docicon='fa-file-word-o'                                                                                                                              
                                         }else if(docicon.indexOf('pdf') > -1){
                                                docicon='fa-file-pdf-o'                                                                                                                            
                                         }else if(docicon.indexOf('xl') > -1){
                                                  docicon='fa-file-excel-o'                 
                                         }else if(docicon.indexOf('ppt') > -1){
                                                  docicon='fa-file-powerpoint-o'                    
                                         }else if(docicon.indexOf('jpg') > -1 || docicon.indexOf('bmp') > -1 || docicon.indexOf('png') > -1 || docicon.indexOf('gif') > -1 || docicon.indexOf('tiff') > -1){
                                                  docicon='fa-file-image-o'                    
                                         }else{
                                              docicon = 'fa-file-o'
                                           }
                                    /////////////////////////////////////
                                    var docEditFunc = "'"+"."+$(this).attr("ows_DocIcon")+"'"+","+"'"+Document_ID+"'"+","+"'"+Document_AttID+"'"
                                   
                                       ////add Table row
                                       $('#'+attactmentTBL+' > tbody').append(
                                          	'<tr>'+
										      '<td scope="row"  ><i aria-hidden="true" class="fa '+docicon+'" ></i> <a attachmentID="'+Document_ID+'" attachmentFolder="'+attachmentFolderID+'" attachmentName="'+Document_Name+'" attachmentLibrary="'+attachmentLibrary+'" href="'+Document_URL+'" target="_blank">'+Document_Name+'</a></td>'+
										      '<td>'+DocumentMOD+'</td>'+
										      '<td><button type="button" onclick="deleteAttachment('+"'"+Document_ID+"'"+')" class="btn btn-danger">Delete <span class="sr-only">'+Document_Name+'</span></button></td>'+
											'</tr>'
                                       
                                       )
                                      ///set document Parameters\
                                                                                                                         
                                                                        
                                       

                                                                                                                         
                                      //////////////////////////////////////////     
                                     })
                                     
                                    }
                                   });
                                   ///////////////////////////////////////////End SP services  


 
}
//////////////////////////////////////////////////////////////////////////////////
////delete document
   function deleteAttachment(docid){
        var docFileRef = $("a[attachmentID='"+docid+"']").attr('href');
        var docname = $("a[attachmentID='"+docid+"']").attr('attachmentName');
        var doclib =  $("a[attachmentID='"+docid+"']").attr('attachmentLibrary');
        var docFolder =  $("a[attachmentID='"+docid+"']").attr('attachmentFolder');
        
                       $().SPServices({
                      operation: "UpdateListItems",
                      listName: doclib,
                      updates: "<Batch OnError='Continue'><Method ID='1' Cmd='Delete'><Field Name='ID'>"+docid+"</Field><Field Name='FileRef'>"+docFileRef +"</Field></Method></Batch>",
                          completefunc: function(xData, Status) {
                          
                             if(Status == 'success'){
                                          //////////Post Vulcan Alert
							        //  newAlert('#Form-Alerts',////Location
										       //  'danger',////Theme
										        // 'Deleted!',////Bold Alert
										        // 'The Document '+docname+' has been successfully deleted.'////Message
										       //  );
									   //////////////////////////
                                     ///refesrh attachments
                                     getAttachmentFiles(doclib, docFolder)
							          
							         // $('#DocDelete').modal('hide')
							         
                                                                                                                                                                                               

                                      }else{
							         //////////Post Vulcan Alert	         
										//newAlert('#Form-Alerts',////Location
										        // 'danger',////Theme
										       //  'Error!',////Bold Alert
										       //  'There was an error saving your changes.'////Message
										       //  )
										////////////////////////////////////////////////// /

							        
							        }
    
                              ////////////////////////                                                                                                                                                                                                                                                                    





                          }

                });

 
   
   }
///////////////////////////////////////////////////////////////////////////////
////////save new attachment link
 function saveLinks(saveMode){
    
    
        ////  Variables
         var postLinkName = '';    
          var postLink = ''; 
          var newPostLinkHtml = '';
          var attachmentlinkArry =[];
          $('.attachmentLink').each(function(){
          var returnedLinks ='<a class="attachmentLink" href="'+$(this).attr('href')+'" >'+$(this).html()+'</a>'
          attachmentlinkArry.push(returnedLinks.replace(/</g,"&#60;").replace(/>/g,"&#62;"))
          })
        if(saveMode != 'update'){
          var postLinkName = $('#LinkNameInput').val();    
          var postLink = $('#LinkURLInput').val(); 
          var newPostLinkHtml = '<a class="attachmentLink" href="'+postLink+'" >'+postLinkName+'</a>';
          attachmentlinkArry.push(newPostLinkHtml.replace(/</g,"&#60;").replace(/>/g,"&#62;")) 
          }
         //  $('#TagsInput option:selected').each(function(){postTags += $(this).val()});
          //    postTags = postTags.substring(postTags.indexOf(';'))  
        
              
             //////Save SPservices
                          $().SPServices({
						        operation: "UpdateListItems",
						        async: false,
						        batchCmd: 'Update',
						        ID:saucePostID,
						        listName: "SAUCE Posts",
						        valuepairs:  [["Links", attachmentlinkArry],
											 ],
											
						        completefunc: function(xData, Status) {
						      
							        if(Status == 'success'){	
							        						        
							            alert('saved');
							            
							            ////hide and reset form
							                  $('#LinkForm').collapse('hide')
							                  $('#LinkNameInput').val('');    
                                              $('#LinkURLInput').val('');
                                               //reset links
							                   getAttachmentLink();
							            //
							        
							        }//////////////////////////////////////
						          
						        }
						    });
                        //////End save SPservice
          
     
    
    
    
    }

////////////////////////////////////////////////////////////
///////get Attachment Documents

function getAttachmentLink(){ 

         ///empty link table
           $('#AttachmentLinksTable > tbody').empty();
         var linkCount= 0;
     
         LinkQuery = '<Query><Where><Eq><FieldRef Name="ID"/><Value Type="Text">'+saucePostID+'</Value></Eq></Where><OrderBy><FieldRef Name="Created" Ascending="False" /></OrderBy></Query>'
                
    ////////////////SPServices Get List Items
                               $().SPServices({
                                        operation: "GetListItems",
                                        async: false,
                                        listName: 'SAUCE Posts',
                                        CAMLViewFields: "<ViewFields><FieldRef Name='ID' /><FieldRef Name='Links' /></ViewFields>",
                                        CAMLQuery:LinkQuery ,
                                        completefunc: function (xData, Status) {
                                          $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                              var linkIcon= 'fa-link';                                      
			                                    var Link_returned = '';
			                                    var Link_Name ='';
                                             var returnedLinks =  $(this).attr("ows_Links");
                                              var returnedLinksArry =  returnedLinks.split(",");
                                                $.each(returnedLinksArry, function( index, value ) {
                                                                  linkCount += 1;
																  Link_returned = value ;
																  Link_Name = 'Link'
																  
																   ////add Table row
                                       $('#AttachmentLinksTable > tbody').append(
                                          	'<tr id="LinkRow'+linkCount+'" >'+
										      '<td scope="row" style="width:80%" ><i aria-hidden="true" class="fa '+linkIcon+'" ></i> '+Link_returned+'</td>'+
										      '<td><button type="button" onclick="deleteLink('+"'"+'LinkRow'+linkCount+"'"+')" class="btn btn-danger">Delete <span class="sr-only">'+Link_Name+'</span></button></td>'+
											'</tr>'
                                       
                                       )
                                    //////////////////////////////////////
																
								});////end each array item
																
																///////////////                                            
					 
                                   

                                                                                                                         
                                      //////////////////////////////////////////     
                                     })
                                     
                                    }
                                   });
                                   ///////////////////////////////////////////End SP services  


 
}
//////////////////////////////////////////////////////////////////////////////////
///////////delete link

function deleteLink(linktoDelete){

//////delete link
  $('#'+linktoDelete).remove();
////refresh link
  saveLinks('update')

}


////////////////////////////////////////// 
////hide link form
function hideLinkForm(){

     $('#LinkForm').collapse('hide')
}
/////////////////////////////////
/////show link form
function showLinkForm(){
                $('#LinkNameInput').val('');    
              $('#LinkURLInput').val('');
              $('#LinkForm').collapse('show')
							                


}
/////////////////////////
/////show Attachment uploader
function showAttachmentForm(uploader){
 
              $('#MixerUploader').collapse('show');
              
         // 
         if(uploader =='attachment' ){
         resetUploader('MixerUploader','SAUCE%20Attachments','Attachment_'+saucePostID );
         }else if(uploader == 'template'){
          resetUploader('MixerUploader','SAUCE%20Templates','Template_'+saucePostID )
         }
							                


}
/////////////////////////
/////////reset SAUCE Post
  function resetSAUCEPost(){
       
     
       var SubtopicArray =[]
           var Query_ValuePairs = "<ViewFields>"+
                             "<FieldRef Name='Title' />"+ 
                             "<FieldRef Name='ID' />"+ 
                             "<FieldRef Name='Description' />"+ 
                             "<FieldRef Name='Topic' />"+
                             "<FieldRef Name='HTML' />"+  
                             "<FieldRef Name='Source_x0020_Code' />"+
                             "<FieldRef Name='Note' />"+                                                            
                              "</ViewFields>"
 
         
                  ////////////////SPServices Get List Items Office Directory
                   $().SPServices({
                               operation: "GetListItems",
                               async: false,
                               listName: "SAUCE Posts",
                               CAMLViewFields: Query_ValuePairs,
                               CAMLQuery: '<Query><Where><Eq><FieldRef Name="ID"/><Value Type="Text">'+saucePostID+'</Value></Eq></Where><OrderBy><FieldRef Name="Title" Ascending="False" /></OrderBy></Query>',
                               completefunc: function (xData, Status) {
                        $(xData.responseXML).SPFilterNode("z:row").each(function() {
                                                                                                                                                                                                                                                                                                                                                                     
                                                       var TopicTitle = $(this).attr("ows_Title");
                                                       var TopicID = $(this).attr("ows_ID");
                                                       var TopicDescription = $(this).attr("ows_Description");if(TopicDescription === undefined){TopicDescription =''}
                                                       var TopicHtml = $(this).attr("ows_HTML");if(TopicHtml === undefined){TopicHtml =''};
                                                       var SourceCode ="";
                                                       var TopicParent = 'SAUCETopic'+$(this).attr("ows_Topic").substring(0,$(this).attr("ows_Topic").indexOf(';'));
                                                       var TopicParentLI =TopicParent+'-Li'
                                                       var TopicParentUL =TopicParent+'-Ul'
                                                       var PostHtml= $(this).attr("ows_HTML");
                                                       var SourceCodeDisplay =""; 
                                                       var PostNote = '';
                                                       
                                                       
                                                       ///////set Details div
                                                       $('#detail-div').prepend(
                                                           '<h2 id="display-topic-title" class="page-header primeColor"  style="color: rgb(0, 114, 188);">'+
															TopicTitle +
															'</h2>'+
															'<h3 style="display:none" id="display-post-title">Post Title</h3>'+
													        '<p id="display-post-description " class="lead ">There are general types '+
															'or classification of accessibility tools. One of the classifications are '+
															'Free manual accessibility tools available to developers and web '+
															'designers to ensure that the site they are developing meets established '+
															'accessibility standards and guidelines (Section 508 and WCAG 2.0).&nbsp;'+ 
															'The understanding of web-based accessibility requires more than just '+
															'accessibility tools; it requires human judgment. The real key is to '+
															'learn and understand the web accessibility standards and guidelines '+
															'rather than relying on a tool to determine if a page is accessible or'+ 
															'not.</p>'+
													        '<p id="display-post-Article " class="lead ">ZoomText is a magnification '+
															'and screen reading software program that allows you to see and hear '+
															'everything on the computer screen as well as providing access to'+ 
															'applications, documents, email and the Internet. The software assists '+
															'the visually impaired individuals who have:</p>'
                                                           )  
                                                       
                                                        
                                                          
                                    })
                                      }
                                   })  
                    //////////End SpServcies
 
       
 
     
     
 ////////  
   
          
       
   };

/////////////////////////////////////////////// 